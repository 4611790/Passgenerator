# password-generator
Simple password generator in Qt6/C++ for Windows/Android

![image](https://github.com/eXGhsRBm/password-generator/assets/130750054/df1c131c-c8c3-4c51-8b34-54f2c23d7b60)

