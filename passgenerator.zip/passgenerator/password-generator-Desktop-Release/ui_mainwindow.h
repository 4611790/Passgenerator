/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_6;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_5;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_7;
    QSpinBox *spinBox_number_letters_down;
    QPushButton *pushButton_letters_down_decrease;
    QPushButton *pushButton_letters_down_increase;
    QSpacerItem *horizontalSpacer_4;
    QCheckBox *checkBox_letters_down;
    QLineEdit *lineEdit_letters_down;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_8;
    QSpinBox *spinBox_number_letters_up;
    QPushButton *pushButton_letters_up_decrease;
    QPushButton *pushButton_letters_up_increase;
    QSpacerItem *horizontalSpacer_11;
    QCheckBox *checkBox_letters_up;
    QLineEdit *lineEdit_letters_up;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_9;
    QSpinBox *spinBox_number_digits;
    QPushButton *pushButton_digits_decrease;
    QPushButton *pushButton_digits_increase;
    QSpacerItem *horizontalSpacer_12;
    QCheckBox *checkBox_digits;
    QLineEdit *lineEdit_digits;
    QGroupBox *groupBox_4;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_10;
    QSpinBox *spinBox_number_special;
    QPushButton *pushButton_special_decrease;
    QPushButton *pushButton_special_increase;
    QSpacerItem *horizontalSpacer_13;
    QCheckBox *checkBox_special;
    QLineEdit *lineEdit_special;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_14;
    QPushButton *pushButton_reset;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_6;
    QLabel *label;
    QCheckBox *checkBox;
    QLineEdit *lineEdit_generation_result;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_generation;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_copy;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *verticalSpacer;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(308, 623);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout_6 = new QVBoxLayout(centralwidget);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        groupBox_5 = new QGroupBox(centralwidget);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        verticalLayout_5 = new QVBoxLayout(groupBox_5);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        groupBox = new QGroupBox(groupBox_5);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_7);

        spinBox_number_letters_down = new QSpinBox(groupBox);
        spinBox_number_letters_down->setObjectName(QString::fromUtf8("spinBox_number_letters_down"));
        spinBox_number_letters_down->setMaximum(8);
        spinBox_number_letters_down->setValue(4);

        horizontalLayout_3->addWidget(spinBox_number_letters_down);

        pushButton_letters_down_decrease = new QPushButton(groupBox);
        pushButton_letters_down_decrease->setObjectName(QString::fromUtf8("pushButton_letters_down_decrease"));

        horizontalLayout_3->addWidget(pushButton_letters_down_decrease);

        pushButton_letters_down_increase = new QPushButton(groupBox);
        pushButton_letters_down_increase->setObjectName(QString::fromUtf8("pushButton_letters_down_increase"));

        horizontalLayout_3->addWidget(pushButton_letters_down_increase);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);

        checkBox_letters_down = new QCheckBox(groupBox);
        checkBox_letters_down->setObjectName(QString::fromUtf8("checkBox_letters_down"));
        checkBox_letters_down->setChecked(true);
        checkBox_letters_down->setTristate(false);

        horizontalLayout_3->addWidget(checkBox_letters_down);


        verticalLayout->addLayout(horizontalLayout_3);

        lineEdit_letters_down = new QLineEdit(groupBox);
        lineEdit_letters_down->setObjectName(QString::fromUtf8("lineEdit_letters_down"));

        verticalLayout->addWidget(lineEdit_letters_down);


        verticalLayout_5->addWidget(groupBox);

        groupBox_2 = new QGroupBox(groupBox_5);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        verticalLayout_2 = new QVBoxLayout(groupBox_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_8);

        spinBox_number_letters_up = new QSpinBox(groupBox_2);
        spinBox_number_letters_up->setObjectName(QString::fromUtf8("spinBox_number_letters_up"));
        spinBox_number_letters_up->setMaximum(8);
        spinBox_number_letters_up->setValue(4);

        horizontalLayout_4->addWidget(spinBox_number_letters_up);

        pushButton_letters_up_decrease = new QPushButton(groupBox_2);
        pushButton_letters_up_decrease->setObjectName(QString::fromUtf8("pushButton_letters_up_decrease"));

        horizontalLayout_4->addWidget(pushButton_letters_up_decrease);

        pushButton_letters_up_increase = new QPushButton(groupBox_2);
        pushButton_letters_up_increase->setObjectName(QString::fromUtf8("pushButton_letters_up_increase"));

        horizontalLayout_4->addWidget(pushButton_letters_up_increase);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_11);

        checkBox_letters_up = new QCheckBox(groupBox_2);
        checkBox_letters_up->setObjectName(QString::fromUtf8("checkBox_letters_up"));
        checkBox_letters_up->setChecked(true);
        checkBox_letters_up->setTristate(false);

        horizontalLayout_4->addWidget(checkBox_letters_up);


        verticalLayout_2->addLayout(horizontalLayout_4);

        lineEdit_letters_up = new QLineEdit(groupBox_2);
        lineEdit_letters_up->setObjectName(QString::fromUtf8("lineEdit_letters_up"));

        verticalLayout_2->addWidget(lineEdit_letters_up);


        verticalLayout_5->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(groupBox_5);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        verticalLayout_3 = new QVBoxLayout(groupBox_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_9);

        spinBox_number_digits = new QSpinBox(groupBox_3);
        spinBox_number_digits->setObjectName(QString::fromUtf8("spinBox_number_digits"));
        spinBox_number_digits->setMaximum(8);
        spinBox_number_digits->setValue(4);

        horizontalLayout_5->addWidget(spinBox_number_digits);

        pushButton_digits_decrease = new QPushButton(groupBox_3);
        pushButton_digits_decrease->setObjectName(QString::fromUtf8("pushButton_digits_decrease"));

        horizontalLayout_5->addWidget(pushButton_digits_decrease);

        pushButton_digits_increase = new QPushButton(groupBox_3);
        pushButton_digits_increase->setObjectName(QString::fromUtf8("pushButton_digits_increase"));

        horizontalLayout_5->addWidget(pushButton_digits_increase);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_12);

        checkBox_digits = new QCheckBox(groupBox_3);
        checkBox_digits->setObjectName(QString::fromUtf8("checkBox_digits"));
        checkBox_digits->setChecked(true);

        horizontalLayout_5->addWidget(checkBox_digits);


        verticalLayout_3->addLayout(horizontalLayout_5);

        lineEdit_digits = new QLineEdit(groupBox_3);
        lineEdit_digits->setObjectName(QString::fromUtf8("lineEdit_digits"));

        verticalLayout_3->addWidget(lineEdit_digits);


        verticalLayout_5->addWidget(groupBox_3);

        groupBox_4 = new QGroupBox(groupBox_5);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        verticalLayout_4 = new QVBoxLayout(groupBox_4);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_10);

        spinBox_number_special = new QSpinBox(groupBox_4);
        spinBox_number_special->setObjectName(QString::fromUtf8("spinBox_number_special"));
        spinBox_number_special->setMaximum(8);
        spinBox_number_special->setValue(4);

        horizontalLayout_6->addWidget(spinBox_number_special);

        pushButton_special_decrease = new QPushButton(groupBox_4);
        pushButton_special_decrease->setObjectName(QString::fromUtf8("pushButton_special_decrease"));

        horizontalLayout_6->addWidget(pushButton_special_decrease);

        pushButton_special_increase = new QPushButton(groupBox_4);
        pushButton_special_increase->setObjectName(QString::fromUtf8("pushButton_special_increase"));

        horizontalLayout_6->addWidget(pushButton_special_increase);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_13);

        checkBox_special = new QCheckBox(groupBox_4);
        checkBox_special->setObjectName(QString::fromUtf8("checkBox_special"));
        checkBox_special->setChecked(true);

        horizontalLayout_6->addWidget(checkBox_special);


        verticalLayout_4->addLayout(horizontalLayout_6);

        lineEdit_special = new QLineEdit(groupBox_4);
        lineEdit_special->setObjectName(QString::fromUtf8("lineEdit_special"));

        verticalLayout_4->addWidget(lineEdit_special);


        verticalLayout_5->addWidget(groupBox_4);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_14);

        pushButton_reset = new QPushButton(groupBox_5);
        pushButton_reset->setObjectName(QString::fromUtf8("pushButton_reset"));

        horizontalLayout->addWidget(pushButton_reset);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout_5->addLayout(horizontalLayout);


        verticalLayout_6->addWidget(groupBox_5);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_6);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_8->addWidget(label);

        checkBox = new QCheckBox(centralwidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setChecked(true);
        checkBox->setTristate(false);

        horizontalLayout_8->addWidget(checkBox);


        verticalLayout_6->addLayout(horizontalLayout_8);

        lineEdit_generation_result = new QLineEdit(centralwidget);
        lineEdit_generation_result->setObjectName(QString::fromUtf8("lineEdit_generation_result"));

        verticalLayout_6->addWidget(lineEdit_generation_result);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButton_generation = new QPushButton(centralwidget);
        pushButton_generation->setObjectName(QString::fromUtf8("pushButton_generation"));

        horizontalLayout_2->addWidget(pushButton_generation);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        pushButton_copy = new QPushButton(centralwidget);
        pushButton_copy->setObjectName(QString::fromUtf8("pushButton_copy"));

        horizontalLayout_2->addWidget(pushButton_copy);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_5);


        verticalLayout_6->addLayout(horizontalLayout_2);

        verticalSpacer = new QSpacerItem(20, 2, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_6->addItem(verticalSpacer);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        groupBox_5->setTitle(QString());
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "Lowercase letters", nullptr));
        pushButton_letters_down_decrease->setText(QCoreApplication::translate("MainWindow", "<", nullptr));
        pushButton_letters_down_increase->setText(QCoreApplication::translate("MainWindow", ">", nullptr));
        checkBox_letters_down->setText(QString());
        groupBox_2->setTitle(QCoreApplication::translate("MainWindow", "Uppercase letters", nullptr));
        pushButton_letters_up_decrease->setText(QCoreApplication::translate("MainWindow", "<", nullptr));
        pushButton_letters_up_increase->setText(QCoreApplication::translate("MainWindow", ">", nullptr));
        checkBox_letters_up->setText(QString());
        groupBox_3->setTitle(QCoreApplication::translate("MainWindow", "Numbers", nullptr));
        pushButton_digits_decrease->setText(QCoreApplication::translate("MainWindow", "<", nullptr));
        pushButton_digits_increase->setText(QCoreApplication::translate("MainWindow", ">", nullptr));
        checkBox_digits->setText(QString());
        groupBox_4->setTitle(QCoreApplication::translate("MainWindow", "Symbols", nullptr));
        pushButton_special_decrease->setText(QCoreApplication::translate("MainWindow", "<", nullptr));
        pushButton_special_increase->setText(QCoreApplication::translate("MainWindow", ">", nullptr));
        checkBox_special->setText(QString());
        pushButton_reset->setText(QCoreApplication::translate("MainWindow", "RESET", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "REPETITION OF SYMBOLS", nullptr));
        checkBox->setText(QString());
        pushButton_generation->setText(QCoreApplication::translate("MainWindow", "GENERATION", nullptr));
        pushButton_copy->setText(QCoreApplication::translate("MainWindow", "COPY", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
